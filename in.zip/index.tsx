import React, { useState, useEffect, useRef } from "react";
import { createRoot } from "react-dom/client";
import { GoogleGenAI } from "@google/genai";

// --- Configuration & Types ---

const API_KEY = process.env.API_KEY;
const ai = new GoogleGenAI({ apiKey: API_KEY });

type ViewState = 'home' | 'buy' | 'sell' | 'experts' | 'insights' | 'contact';

type Property = {
  id: number;
  title: string;
  price: string;
  priceValue: number;
  acres: number;
  features: string[];
  type: "Farm" | "Orchard" | "Coastal" | "Acreage";
  description: string;
  imagePrompt: string;
  address: string;
};

type Article = {
  id: number;
  title: string;
  date: string;
  category: string;
  excerpt: string;
  imagePrompt: string;
};

// --- Mock Data ---

const PROPERTIES: Property[] = [
  {
    id: 1,
    title: "The Old Mill Station",
    price: "$1,250,000",
    priceValue: 1250000,
    acres: 150,
    features: ["Cane Fields", "Historic Barn", "Creek Frontage"],
    type: "Farm",
    description: "A piece of Bundaberg history. Rolling cane fields meet the Burnett River. Includes a fully restored 1920s homestead and active cane production contracts.",
    imagePrompt: "Aerial view of a lush green sugarcane farm in Bundaberg Queensland at golden hour, red soil, tractors in distance, highly detailed, rustic style",
    address: "452 River Road, South Kolan"
  },
  {
    id: 2,
    title: "Macadamia Heights",
    price: "$890,000",
    priceValue: 890000,
    acres: 25,
    features: ["Mature Orchard", "Shedding", "3 Bed Homestead"],
    type: "Orchard",
    description: "Productive macadamia orchard with a renovated Queenslander homestead. 2,000 trees in peak production with automated irrigation systems.",
    imagePrompt: "Rows of macadamia nut trees in an orchard, Bundaberg, red volcanic soil, sunny australian afternoon, farm shed in background",
    address: "88 Nutgrove Lane, Sharon"
  },
  {
    id: 3,
    title: "Bargara Coastal Acreage",
    price: "$1,450,000",
    priceValue: 1450000,
    acres: 12,
    features: ["Ocean Breeze", "Modern Build", "Paddock"],
    type: "Coastal",
    description: "Where the country meets the coast. Rare acreage just minutes from Bargara Beach. Architecturally designed home with horse paddocks.",
    imagePrompt: "Australian coastal rural property, modern farmhouse architecture, tall grass, dunes in background, blue sky, bright and airy",
    address: "12 Sandy Track, Bargara"
  },
  {
    id: 4,
    title: "Red Soil Retreat",
    price: "$675,000",
    priceValue: 675000,
    acres: 5,
    features: ["Hobby Farm", "Dam", "Fenced"],
    type: "Acreage",
    description: "Perfect for the hobby farmer. Rich volcanic soil and established fruit trees. Cozy 2-bedroom cottage with wide wrap-around verandahs.",
    imagePrompt: "Small hobby farm cottage with a wrap-around verandah, vegetable gardens, red dirt path, australian native flowers",
    address: "23 Volcanic Rise, Hummock"
  },
  {
    id: 5,
    title: "Burnett River Grazing",
    price: "$2,100,000",
    priceValue: 2100000,
    acres: 400,
    features: ["Cattle Yards", "River Access", "Water License"],
    type: "Farm",
    description: "Prime grazing land with extensive river frontage and secure water allocation. heavy carrying capacity with improved pastures.",
    imagePrompt: "Cattle grazing on green pasture next to a wide river in Queensland, eucalyptus trees, sunset lighting, cinematic landscape",
    address: "101 Cattle Drive, Bucca"
  },
  {
    id: 6,
    title: "Sunnyvale Citrus",
    price: "$950,000",
    priceValue: 950000,
    acres: 40,
    features: ["Lemon & Lime", "Packing Shed", "Solar"],
    type: "Orchard",
    description: "Established citrus orchard in full production. Excellent income potential with established distribution channels and packing infrastructure.",
    imagePrompt: "Close up of citrus trees laden with fruit, sunny orchard, farm equipment, bright yellow and green colors",
    address: "55 Lemon Grove Rd, Wallaville"
  },
];

const ARTICLES: Article[] = [
  {
    id: 1,
    title: "Water Allocation 2024: What Buyers Need to Know",
    date: "Oct 12, 2024",
    category: "Market Trends",
    excerpt: "With the Paradise Dam restoration works confirmed, water security in the Burnett region is shifting. We analyze the impact on irrigation license values.",
    imagePrompt: "Wide river flowing through Australian farmland, irrigation equipment spraying water, sun lens flare, agricultural technology"
  },
  {
    id: 2,
    title: "Cane vs. Macadamias: An ROI Comparison",
    date: "Sep 28, 2024",
    category: "Agri-Business",
    excerpt: "As more traditional cane farms convert to tree crops, we look at the setup costs versus long-term yield for Bundaberg's two biggest exports.",
    imagePrompt: "Split image, half sugar cane field, half macadamia tree, red soil, high contrast, agricultural analysis concept"
  },
  {
    id: 3,
    title: "The Rise of Lifestyle Acreage in 4670",
    date: "Sep 15, 2024",
    category: "Lifestyle",
    excerpt: "Post-pandemic migration has seen a 40% surge in demand for 5-10 acre plots. Here is what city buyers are looking for in a rural retreat.",
    imagePrompt: "Happy family walking through tall grass on a rural property, sunset, Australian gum trees, lens flare, lifestyle photography"
  }
];

// --- Icons (SVG) ---

const IconSearch = () => (<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>);
const IconMapPin = () => (<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>);
const IconPhone = () => (<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>);
const IconMenu = () => (<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>);
const IconX = () => (<svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>);
const IconArrowRight = () => (<svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>);
const IconCheck = () => (<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>);
const IconBaby = () => (<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>);

// --- Custom Hook for AI Images with Caching ---

// Global cache to persist images between view changes
const imageCache = new Map<string, string>();

const useGeneratedImage = (prompt: string, aspectRatio: string = "4:3") => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const hasFetched = useRef(false);

  useEffect(() => {
    // Check cache first
    const cacheKey = `${prompt}-${aspectRatio}`;
    if (imageCache.has(cacheKey)) {
      setImageUrl(imageCache.get(cacheKey)!);
      return;
    }

    if (hasFetched.current) return;
    hasFetched.current = true;
    
    if (!API_KEY) {
       console.warn("No API Key found. Skipping image generation.");
       return;
    }

    const fetchImage = async () => {
      setLoading(true);
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: { parts: [{ text: prompt }] },
          config: {
             imageConfig: {
               aspectRatio: aspectRatio as any
             }
          }
        });
        
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const url = `data:image/png;base64,${part.inlineData.data}`;
            setImageUrl(url);
            imageCache.set(cacheKey, url); // Store in cache
            break;
          }
        }
      } catch (error) {
        console.error("Failed to generate image:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchImage();
  }, [prompt, aspectRatio]);

  return { imageUrl, loading };
};

// --- Shared Components ---

const NavBar = ({ setView, currentView, toggleModal }: { setView: (v: ViewState) => void, currentView: ViewState, toggleModal: () => void }) => {
  const navLinkClass = (view: ViewState) => 
    `cursor-pointer font-medium transition-colors ${currentView === view ? 'text-barn-700 font-bold' : 'text-earth-600 hover:text-barn-700'}`;

  return (
    <nav className="bg-white/90 backdrop-blur-md sticky top-0 z-50 border-b border-field-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setView('home')}>
             <div className="w-8 h-8 bg-barn-700 rounded-sm flex items-center justify-center text-white font-serif font-bold text-xl">P</div>
             <div className="flex flex-col">
               <span className="font-serif font-bold text-barn-900 text-xl leading-none">PublicListings</span>
               <span className="text-earth-500 text-xs tracking-widest uppercase">Bundaberg</span>
             </div>
          </div>
          <div className="hidden md:flex space-x-8 items-center">
            <a onClick={() => setView('buy')} className={navLinkClass('buy')}>Buy</a>
            <a onClick={() => setView('sell')} className={navLinkClass('sell')}>Sell</a>
            <a onClick={() => setView('experts')} className={navLinkClass('experts')}>Rural Experts</a>
            <a onClick={() => setView('insights')} className={navLinkClass('insights')}>Market Insights</a>
            <button 
              onClick={toggleModal}
              className="bg-barn-700 text-white px-5 py-2.5 rounded hover:bg-barn-800 transition-colors shadow-sm font-medium"
            >
              Contact Us
            </button>
          </div>
          <div className="md:hidden text-earth-600">
            <IconMenu />
          </div>
        </div>
      </div>
    </nav>
  );
};

const PropertyCard: React.FC<{ property: Property }> = ({ property }) => {
  const { imageUrl, loading } = useGeneratedImage(property.imagePrompt);

  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden break-inside-avoid mb-6 flex flex-col group border border-field-200">
      <div className="relative h-64 bg-earth-100 overflow-hidden">
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={property.title} 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 animate__animated animate__fadeIn"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-field-100 text-field-400">
             {loading ? <span className="animate-pulse">Loading View...</span> : <span>Image Unavailable</span>}
          </div>
        )}
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur text-barn-800 text-xs font-bold px-3 py-1 rounded-sm uppercase tracking-wide">
          {property.type}
        </div>
      </div>
      <div className="p-6">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-serif font-bold text-earth-900 group-hover:text-barn-700 transition-colors">
            {property.title}
          </h3>
        </div>
        <p className="text-barn-700 font-bold text-lg mb-1">{property.price}</p>
        <p className="text-earth-400 text-xs uppercase tracking-wide mb-4">{property.address}</p>
        
        <div className="flex items-center text-earth-500 text-sm mb-4 space-x-4 border-b border-field-100 pb-4">
           <div className="flex items-center"><span className="font-semibold text-earth-700 mr-1">{property.acres}</span> Acres</div>
           <div className="w-1 h-1 bg-earth-300 rounded-full"></div>
           <div className="flex items-center"><IconMapPin /> <span className="ml-1">Bundaberg Region</span></div>
        </div>

        <p className="text-earth-600 text-sm line-clamp-2 mb-4 leading-relaxed">
          {property.description}
        </p>

        <div className="flex flex-wrap gap-2 mb-6">
          {property.features.slice(0,2).map((feat, i) => (
            <span key={i} className="text-xs bg-field-100 text-earth-700 px-2 py-1 rounded-sm border border-field-200">
              {feat}
            </span>
          ))}
          {property.features.length > 2 && (
             <span className="text-xs bg-field-50 text-earth-500 px-2 py-1 rounded-sm border border-field-100">
               +{property.features.length - 2} more
             </span>
          )}
        </div>

        <button className="w-full py-2 border border-barn-700 text-barn-700 font-medium rounded hover:bg-barn-50 transition-colors text-sm">
          View Listing
        </button>
      </div>
    </div>
  );
};

const Footer = ({ setView }: { setView: (v: ViewState) => void }) => (
  <footer className="bg-earth-900 text-earth-400 py-12 border-t border-earth-800">
    <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
      <div>
        <div className="flex items-center gap-2 mb-4 cursor-pointer" onClick={() => setView('home')}>
           <div className="w-6 h-6 bg-barn-700 rounded-sm flex items-center justify-center text-white font-serif font-bold text-sm">P</div>
           <span className="font-serif font-bold text-white text-lg">PublicListings</span>
        </div>
        <p className="text-sm text-earth-500">
          Bundaberg's premier agency for rural, agricultural, and lifestyle real estate. Rooted in red soil.
        </p>
      </div>
      
      <div>
        <h4 className="text-white font-bold mb-4 uppercase tracking-wider text-xs">Real Estate</h4>
        <ul className="space-y-2 text-sm">
          <li><button onClick={() => setView('buy')} className="hover:text-white transition-colors">Buy Property</button></li>
          <li><button onClick={() => setView('sell')} className="hover:text-white transition-colors">Sell With Us</button></li>
          <li><button onClick={() => setView('buy')} className="hover:text-white transition-colors">Recent Sales</button></li>
        </ul>
      </div>

      <div>
        <h4 className="text-white font-bold mb-4 uppercase tracking-wider text-xs">Company</h4>
        <ul className="space-y-2 text-sm">
          <li><button onClick={() => setView('experts')} className="hover:text-white transition-colors">Our Team</button></li>
          <li><button onClick={() => setView('insights')} className="hover:text-white transition-colors">Market Insights</button></li>
          <li><button onClick={() => setView('contact')} className="hover:text-white transition-colors">Contact</button></li>
        </ul>
      </div>

      <div>
        <h4 className="text-white font-bold mb-4 uppercase tracking-wider text-xs">Get in Touch</h4>
        <ul className="space-y-2 text-sm">
          <li className="flex items-center gap-2"><IconPhone /> (07) 4152 0000</li>
          <li className="flex items-center gap-2"><IconMapPin /> 123 Bourbong St, Bundaberg</li>
        </ul>
      </div>
    </div>
    <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-earth-800 text-xs text-center text-earth-600">
      © 2024 PublicListings Real Estate. All rights reserved. Servicing the Wide Bay Region.
    </div>
  </footer>
);

const InquiryModal = ({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div 
        className="absolute inset-0 bg-earth-900/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      ></div>
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-lg relative z-10 overflow-hidden animate__animated animate__fadeInUp animate__faster">
        <div className="bg-barn-700 p-6 flex justify-between items-center">
          <h3 className="text-xl font-serif font-bold text-white">Make an Inquiry</h3>
          <button onClick={onClose} className="text-white/80 hover:text-white"><IconX /></button>
        </div>
        <div className="p-8">
          <form className="space-y-4">
             <div>
               <label className="block text-sm font-medium text-earth-700 mb-1">Name</label>
               <input type="text" className="w-full px-4 py-2 border border-earth-300 rounded-md focus:ring-2 focus:ring-barn-500 focus:outline-none" placeholder="Jane Doe" />
             </div>
             <div>
               <label className="block text-sm font-medium text-earth-700 mb-1">Phone</label>
               <input type="tel" className="w-full px-4 py-2 border border-earth-300 rounded-md focus:ring-2 focus:ring-barn-500 focus:outline-none" placeholder="0400 000 000" />
             </div>
             <div>
               <label className="block text-sm font-medium text-earth-700 mb-1">Message</label>
               <textarea rows={4} className="w-full px-4 py-2 border border-earth-300 rounded-md focus:ring-2 focus:ring-barn-500 focus:outline-none" placeholder="I'm interested in the property at..."></textarea>
             </div>
             <button type="button" onClick={onClose} className="w-full bg-barn-700 text-white font-bold py-3 rounded-md hover:bg-barn-800 transition-colors shadow-sm">
               Send Inquiry
             </button>
          </form>
        </div>
      </div>
    </div>
  );
};

// --- Page Views ---

const HomePage = ({ setView }: { setView: (v: ViewState) => void }) => {
  const { imageUrl, loading } = useGeneratedImage(
    "Wide panoramic shot of a classic Queenslander farmhouse in Bundaberg at sunset, golden light hitting cane fields in foreground, rustic fence, wide open sky with soft clouds, photorealistic, 4k",
    "16:9"
  );
  const [filter, setFilter] = useState("All");
  const filteredProperties = filter === "All" ? PROPERTIES : PROPERTIES.filter(p => p.type === filter);

  return (
    <>
      {/* Maternity Leave Notice Banner */}
      <div className="bg-field-100 border-b border-field-300 py-3 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-center gap-3 text-center sm:text-left">
           <div className="text-barn-700 p-1.5 bg-barn-100 rounded-full"><IconBaby /></div>
           <p className="text-sm text-earth-700 font-medium">
             <span className="font-bold text-barn-800">Family Update:</span> Sarah commences maternity leave Nov 13, 2025. 
             We will be closing early for Christmas and won't be taking calls until <span className="font-bold">Jan 1st</span>. 
             Emails will be checked nightly. Thank you for supporting our family business.
           </p>
        </div>
      </div>

      {/* Hero */}
      <div className="relative h-[600px] w-full bg-earth-200 overflow-hidden flex items-center justify-center">
        {imageUrl ? (
          <div 
            className="absolute inset-0 bg-cover bg-center animate__animated animate__fadeIn"
            style={{ backgroundImage: `url(${imageUrl})` }}
          />
        ) : (
          <div className="absolute inset-0 bg-earth-200 flex items-center justify-center">
               <div className="text-center">
                  <div className="w-12 h-12 border-4 border-barn-400 border-t-barn-700 rounded-full animate-spin mx-auto mb-4"></div>
                  <p className="text-earth-500 font-serif italic">{loading ? "Capturing the sunset..." : "Waiting for visuals..."}</p>
               </div>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-earth-900/70 via-earth-900/30 to-transparent"></div>
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto mt-10">
          <span className="inline-block py-1 px-3 border border-white/30 rounded-full text-white/90 text-sm font-medium tracking-wider mb-4 bg-black/20 backdrop-blur-sm animate__animated animate__fadeInDown">
            BUNDABERG & SURROUNDS
          </span>
          <h1 className="text-4xl md:text-6xl font-serif text-white font-bold mb-6 shadow-sm animate__animated animate__fadeInUp">
            Find Your Place in the Country
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-10 font-light max-w-2xl mx-auto animate__animated animate__fadeInUp animate__delay-1s">
            Specializing in rural acreage, cane farms, and lifestyle properties across the Wide Bay region.
          </p>
          <div className="bg-white p-2 rounded-lg shadow-xl max-w-3xl mx-auto flex flex-col md:flex-row gap-2 animate__animated animate__fadeInUp animate__delay-1s">
             <div className="flex-grow relative">
               <div className="absolute left-3 top-3 text-earth-400"><IconSearch /></div>
               <input 
                 type="text" 
                 placeholder="Search by suburb, postcode, or property ID" 
                 className="w-full pl-10 pr-4 py-3 rounded-md bg-field-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-barn-200 text-earth-800 placeholder-earth-400"
               />
             </div>
             <button onClick={() => setView('buy')} className="bg-barn-700 text-white px-8 py-3 rounded-md font-medium hover:bg-barn-800 transition-colors w-full md:w-auto">
               Search
             </button>
          </div>
        </div>
      </div>

      {/* Featured Section */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl font-serif font-bold text-earth-900 mb-3">Featured Properties</h2>
            <p className="text-earth-600 max-w-xl">
              Explore our curated selection of Bundaberg's finest rural and lifestyle opportunities.
            </p>
          </div>
          <div className="flex space-x-2 mt-6 md:mt-0 overflow-x-auto pb-2 md:pb-0 w-full md:w-auto">
            {["All", "Farm", "Orchard", "Coastal", "Acreage"].map(type => (
              <button
                key={type}
                onClick={() => setFilter(type)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                  filter === type 
                  ? "bg-earth-800 text-white shadow-md" 
                  : "bg-white text-earth-600 border border-earth-200 hover:bg-earth-50"
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>
        <div className="masonry-grid">
          {filteredProperties.slice(0, 3).map(property => (
            <PropertyCard key={property.id} property={property} />
          ))}
        </div>
        <div className="text-center mt-12">
           <button onClick={() => setView('buy')} className="inline-flex items-center text-barn-700 font-bold hover:text-barn-900 border-b-2 border-barn-200 hover:border-barn-600 pb-1 transition-colors">
             View All Listings <span className="ml-2"><IconArrowRight /></span>
           </button>
        </div>
      </section>

      {/* CTA Band */}
      <section className="bg-field-500 py-16 text-earth-900 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 relative z-10 flex flex-col md:flex-row items-center justify-between">
           <div className="mb-6 md:mb-0 max-w-2xl">
              <h2 className="text-3xl font-serif font-bold mb-2">Thinking of selling your farm?</h2>
              <p className="text-earth-900/80 text-lg">We have a waiting list of qualified buyers looking for cane, orchard, and grazing country.</p>
           </div>
           <button onClick={() => setView('sell')} className="bg-earth-900 text-white px-8 py-4 rounded font-bold hover:bg-earth-800 transition-colors shadow-lg whitespace-nowrap">
             Get a Free Appraisal
           </button>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
      </section>
    </>
  );
};

const BuyPage = () => {
  const { imageUrl } = useGeneratedImage("Green tractor in a red dirt field in Bundaberg, blue sky, wide angle, high quality", "16:9");
  const [activeType, setActiveType] = useState("All");

  const filtered = activeType === "All" ? PROPERTIES : PROPERTIES.filter(p => p.type === activeType);

  return (
    <div className="animate__animated animate__fadeIn">
      {/* Header */}
      <div className="relative h-64 bg-earth-800 overflow-hidden">
        {imageUrl && <div className="absolute inset-0 bg-cover bg-center opacity-40 animate__animated animate__fadeIn" style={{ backgroundImage: `url(${imageUrl})` }} />}
        <div className="absolute inset-0 bg-gradient-to-r from-earth-900/90 to-transparent"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 h-full flex flex-col justify-center">
          <h1 className="text-4xl font-serif font-bold text-white mb-2">Buy Rural Property</h1>
          <p className="text-white/70 max-w-xl">From lifestyle blocks at the Hummock to commercial scale cane farms in the Gooburrum belt.</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white border-b border-field-200 sticky top-20 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex overflow-x-auto gap-4 items-center">
          <span className="text-sm font-bold text-earth-400 uppercase tracking-wide mr-2">Filter:</span>
          {["All", "Farm", "Orchard", "Coastal", "Acreage"].map(type => (
            <button
              key={type}
              onClick={() => setActiveType(type)}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${
                activeType === type ? 'bg-barn-100 text-barn-800 border border-barn-200' : 'bg-field-50 text-earth-600 border border-field-200 hover:bg-field-100'
              }`}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {/* Listings */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map(p => <PropertyCard key={p.id} property={p} />)}
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-20 bg-field-50 rounded-lg border border-field-200 border-dashed">
            <h3 className="text-xl font-serif text-earth-500 mb-2">No properties found</h3>
            <p className="text-earth-400">Try adjusting your filters.</p>
          </div>
        )}
      </div>
    </div>
  );
};

const SellPage = () => {
  const { imageUrl } = useGeneratedImage("Farmer shaking hands with a real estate agent in front of a white farmhouse, golden hour, fence, friendly atmosphere", "16:9");

  return (
    <div className="animate__animated animate__fadeIn">
      <div className="relative h-[400px] bg-earth-800 overflow-hidden flex items-center">
        {imageUrl && <div className="absolute inset-0 bg-cover bg-center opacity-50 animate__animated animate__fadeIn" style={{ backgroundImage: `url(${imageUrl})` }} />}
        <div className="relative z-10 max-w-7xl mx-auto px-4 w-full">
           <div className="bg-white/95 backdrop-blur-md p-8 md:p-12 rounded-sm shadow-xl max-w-xl">
              <span className="text-barn-600 font-bold tracking-wider uppercase text-xs mb-2 block">Sell With Confidence</span>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-earth-900 mb-4">Real Results for Real Property</h1>
              <p className="text-earth-600 mb-6 leading-relaxed">
                We understand that selling a rural property isn't just a transaction—it's a transition. 
                Our team combines deep local agricultural knowledge with modern marketing to reach buyers from Brisbane to Sydney.
              </p>
              <button className="bg-barn-700 text-white font-bold py-3 px-6 rounded hover:bg-barn-800 transition-colors w-full md:w-auto">
                Request Appraisal
              </button>
           </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
             <h2 className="text-3xl font-serif font-bold text-earth-900 mb-6">Why List With PublicListings?</h2>
             <div className="space-y-6">
               {[
                 { title: "Red Soil Specialists", desc: "We know the difference between grey sandy loam and prime red volcanic soil, and we know how to sell its value." },
                 { title: "National Reach", desc: "Your property is marketed not just locally, but to our database of interstate investors looking for Bundaberg's high yields." },
                 { title: "Transparent Process", desc: "No hidden marketing fees. No nonsense. Just honest feedback and hard work until the contract is signed." }
               ].map((item, i) => (
                 <div key={i} className="flex gap-4">
                    <div className="mt-1 text-barn-600"><IconCheck /></div>
                    <div>
                      <h4 className="font-bold text-earth-900 text-lg">{item.title}</h4>
                      <p className="text-earth-600 leading-relaxed">{item.desc}</p>
                    </div>
                 </div>
               ))}
             </div>
          </div>
          <div className="bg-field-50 p-8 rounded-lg border border-field-200">
             <h3 className="text-2xl font-serif font-bold text-earth-900 mb-6">Request Property Appraisal</h3>
             <form className="space-y-4">
               <div className="grid grid-cols-2 gap-4">
                 <div>
                   <label className="block text-xs font-bold text-earth-500 uppercase mb-1">First Name</label>
                   <input type="text" className="w-full p-2 border border-earth-300 rounded focus:border-barn-500 outline-none" />
                 </div>
                 <div>
                   <label className="block text-xs font-bold text-earth-500 uppercase mb-1">Last Name</label>
                   <input type="text" className="w-full p-2 border border-earth-300 rounded focus:border-barn-500 outline-none" />
                 </div>
               </div>
               <div>
                 <label className="block text-xs font-bold text-earth-500 uppercase mb-1">Property Address</label>
                 <input type="text" className="w-full p-2 border border-earth-300 rounded focus:border-barn-500 outline-none" />
               </div>
               <div className="grid grid-cols-2 gap-4">
                 <div>
                   <label className="block text-xs font-bold text-earth-500 uppercase mb-1">Property Type</label>
                   <select className="w-full p-2 border border-earth-300 rounded focus:border-barn-500 outline-none bg-white">
                     <option>Cane Farm</option>
                     <option>Orchard</option>
                     <option>Grazing</option>
                     <option>Lifestyle Acreage</option>
                   </select>
                 </div>
                 <div>
                   <label className="block text-xs font-bold text-earth-500 uppercase mb-1">Est. Acreage</label>
                   <input type="text" className="w-full p-2 border border-earth-300 rounded focus:border-barn-500 outline-none" />
                 </div>
               </div>
               <button className="w-full bg-earth-800 text-white font-bold py-3 rounded hover:bg-earth-900 transition-colors mt-2">
                 Submit Request
               </button>
             </form>
          </div>
        </div>
      </div>
    </div>
  );
};

const ExpertsPage = () => {
  const { imageUrl } = useGeneratedImage("Husband and wife real estate team standing in a beautiful macadamia orchard, smiling warm and friendly, australian country style, morning light", "21:9");

  const team = [
    { 
      name: "Sarah Jenkins", 
      role: "Co-Founder & Licensee (Taking Maternity Leave)", 
      specialty: "Rural Strategy & Contracts",
      bio: "Sarah is the heart of PublicListings. Born in South Kolan, she has brokered some of the region's largest cane consolidations. She will be on maternity leave from Nov 13, 2025, taking some well-deserved time to grow the next generation of farmers."
    },
    { 
      name: "Tom Jenkins", 
      role: "Co-Founder & Lead Agent", 
      specialty: "Orchards, Water & Sales",
      bio: "Tom handles the boots-on-the-ground work. With a background in agronomy, he knows the soil science behind every sale. While Sarah is away, Tom will be managing all active listings and enquiries after Jan 1st."
    }
  ];

  return (
    <div className="animate__animated animate__fadeIn">
      <div className="h-80 relative bg-earth-200 overflow-hidden">
        {imageUrl && <div className="absolute inset-0 bg-cover bg-center animate__animated animate__fadeIn" style={{ backgroundImage: `url(${imageUrl})` }} />}
        <div className="absolute inset-0 bg-earth-900/60 flex items-center justify-center text-center">
          <div>
            <h1 className="text-4xl font-serif font-bold text-white mb-4">A Family Partnership</h1>
            <p className="text-white/80 text-lg max-w-2xl mx-auto px-4">
              PublicListings is proudly owned and operated by husband and wife team, Sarah & Tom Jenkins.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-5xl mx-auto">
          {team.map((member, idx) => (
             <div key={idx} className="flex flex-col text-center bg-white p-8 rounded-lg shadow-md border border-field-200">
                <div className="w-48 h-48 bg-field-200 rounded-full mx-auto mb-6 overflow-hidden border-4 border-field-100 shadow-inner relative">
                   <div className="w-full h-full flex items-center justify-center text-field-400 bg-field-100">
                      <span className="text-5xl font-serif text-field-300">{member.name[0]}</span>
                   </div>
                </div>
                <h3 className="text-2xl font-serif font-bold text-earth-900">{member.name}</h3>
                <p className="text-barn-600 font-bold uppercase text-xs tracking-wider mb-4 h-8 flex items-center justify-center">{member.role}</p>
                <div className="w-12 h-1 bg-barn-200 mx-auto mb-4"></div>
                <p className="text-earth-600 leading-relaxed italic">
                  "{member.bio}"
                </p>
             </div>
          ))}
        </div>
        
        <div className="mt-20 bg-field-50 p-12 rounded-lg text-center border-t-4 border-barn-700">
           <h2 className="text-3xl font-serif font-bold text-earth-900 mb-6">Our Family Philosophy</h2>
           <p className="text-lg text-earth-700 max-w-3xl mx-auto leading-relaxed">
             "As a husband and wife team, we treat every client like a neighbor. We believe in the enduring value of the Bundaberg region. Whether it's a multi-generational cane farm or a first home on a few acres, we handle every transaction personally. With our family growing this year, we appreciate your patience and support during the holiday season."
           </p>
        </div>
      </div>
    </div>
  );
};

const InsightsPage = () => {
  return (
    <div className="animate__animated animate__fadeIn">
      <div className="bg-earth-100 py-20 border-b border-earth-200">
        <div className="max-w-4xl mx-auto px-4 text-center">
           <span className="text-barn-600 font-bold tracking-wider uppercase text-sm mb-4 block">Bundaberg Market Watch</span>
           <h1 className="text-4xl md:text-5xl font-serif font-bold text-earth-900 mb-6">Insights from the Field</h1>
           <p className="text-xl text-earth-600 leading-relaxed">
             Analysis, trends, and news for the Wide Bay agricultural sector. 
             Stay informed on land values, commodity prices, and water security.
           </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 gap-12">
           {ARTICLES.map(article => {
             const { imageUrl } = useGeneratedImage(article.imagePrompt, "3:1");
             return (
               <article key={article.id} className="bg-white rounded-lg shadow-sm border border-field-200 overflow-hidden hover:shadow-md transition-shadow group">
                 <div className="h-48 md:h-64 bg-earth-200 overflow-hidden relative">
                   {imageUrl ? (
                     <img src={imageUrl} alt={article.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 animate__animated animate__fadeIn" />
                   ) : (
                     <div className="w-full h-full bg-field-100 flex items-center justify-center text-field-300">Loading Visual...</div>
                   )}
                   <div className="absolute top-4 left-4 bg-barn-700 text-white text-xs font-bold px-3 py-1 rounded uppercase">
                     {article.category}
                   </div>
                 </div>
                 <div className="p-8">
                   <div className="flex items-center text-earth-400 text-sm mb-3">
                     <span>{article.date}</span>
                     <span className="mx-2">•</span>
                     <span>By PublicListings Team</span>
                   </div>
                   <h2 className="text-2xl font-serif font-bold text-earth-900 mb-4 group-hover:text-barn-700 transition-colors">
                     {article.title}
                   </h2>
                   <p className="text-earth-600 mb-6 leading-relaxed">
                     {article.excerpt}
                   </p>
                   <button className="text-barn-700 font-bold hover:text-barn-900 uppercase text-sm tracking-wide flex items-center">
                     Read Full Article <IconArrowRight />
                   </button>
                 </div>
               </article>
             );
           })}
        </div>
      </div>
      
      {/* Newsletter */}
      <div className="bg-barn-900 text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='1' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='3'/%3E%3Ccircle cx='13' cy='13' r='3'/%3E%3C/g%3E%3C/svg%3E")` }}></div>
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <h2 className="text-2xl font-serif font-bold mb-4">Don't miss a beat</h2>
          <p className="text-barn-100 mb-8">
            Get the quarterly Bundaberg Land Value Report delivered to your inbox.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
             <input type="email" placeholder="Enter your email" className="px-6 py-3 rounded-md text-earth-900 w-full sm:w-96 focus:outline-none focus:ring-2 focus:ring-field-400" />
             <button className="bg-field-500 hover:bg-field-400 text-earth-900 font-bold px-8 py-3 rounded-md transition-colors">Subscribe</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

const App = () => {
  const [currentView, setView] = useState<ViewState>('home');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Scroll to top on view change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentView]);

  return (
    <div className="min-h-screen bg-texture-paper font-sans text-earth-800 flex flex-col">
       <NavBar currentView={currentView} setView={setView} toggleModal={() => setIsModalOpen(true)} />
       
       <main className="flex-grow">
         {currentView === 'home' && <HomePage setView={setView} />}
         {currentView === 'buy' && <BuyPage />}
         {currentView === 'sell' && <SellPage />}
         {currentView === 'experts' && <ExpertsPage />}
         {currentView === 'insights' && <InsightsPage />}
         {currentView === 'contact' && <div className="py-20 text-center"><h2 className="text-2xl font-serif">Contact Page Placeholder (Use Modal)</h2></div>}
       </main>
       
       <Footer setView={setView} />
       <InquiryModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </div>
  );
};

const root = createRoot(document.getElementById("root")!);
root.render(<App />);